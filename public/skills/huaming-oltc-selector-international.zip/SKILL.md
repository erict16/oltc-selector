---
name: huaming-oltc-selector
description: >
  Huaming tap-changer selection: paste a transformer nameplate or give duty
  parameters (MVA, kV, current, regulation, tap range) and get a commercial
  OLTC/OCTC type string that really exists in the Huaming catalogue, with a
  short why. Use for tap-changer selection, 选型, type designation, OLTC,
  OCTC, CV2, CM2, SHZV, HWV, WSL, WSG, CMD, star-point vs line-end duty,
  reversing / coarse-fine / linear regulation, Imax, Um, 一拖二 (OLTC + OCTC
  on one transformer), checking whether a Huaming model exists, or decoding
  a type string. Do not use for quotation, pricing, or shipping documents.
allowed-tools: Bash, Read
version: 1.2.5
---

# Huaming Tap-Changer Selector

Paste a transformer nameplate or duty parameters, get a Huaming OLTC/OCTC type string that really exists in the catalogue, with a short reason. For transformer designers, sales engineers, and distributors who need a type before asking for a quote. Huaming catalogue only, other vendors are out of scope. No prices, no quotations.

In:

> SFZ11-25000/110, 110±8×1.25%/10.5 kV, Dyn11, taps at HV neutral, vacuum

Out: `CV2III-350Y/72.5-10193W`, vacuum compound, Ium 350 A, Um 72.5 kV, ±8 mid-3 reversing.

In your AI assistant, paste the duty and ask. To run it yourself: `npx -y oltc-selector@latest` (Node 20+, or `npm i -g oltc-selector` for repeat use). Same selection engine as https://oltc-selector.vercel.app/

---

_The sections below are execution instructions for the AI assistant._

## Must

1. If `oltc` is on PATH, **run it**. Do not guess a model from memory.
2. If `oltc` is missing, run it through npx yourself: `npx -y oltc-selector@latest <flags>` (Node 20+). Do not ask the user to install anything first. For repeat use you may `npm i -g oltc-selector` to put `oltc` on PATH. If `npm`/`npx` is missing, stop and tell them to install Node 20+. Do not fabricate CV2-500 or combined III-D.
3. After the CLI prints a model, **check it** against the brochure rules below. If it fails, say so and do not dress it up as orderable.
4. After a pass, explain **why this type is correct** in 3 to 6 short sentences (family, Ium, Um, Y/D or 3×, tap code, construction). No essays.
5. Output the model **without** `+CMA7` unless the user asked for a drive. Three single-phase poles → **1× CMA7**, not three.
6. **一拖二 / 无载带有载** (one transformer with both an on-load and an off-circuit tap-changer) needs **two** selections: a plain run for the on-load part and an `--octc` run for the off-circuit part. Brochure-check **both** type strings and present them together. Never merge the two duties into one run.
7. When the CLI ends with a **假定** assumptions block (`假定：conn=Y 星点（默认）· …`), relay it to the user verbatim and ask which assumption is wrong, then re-run with the corrected flag. No block only means the watched inputs (conn, regulation, steps, medium, mount, phases, and k/step on the capacity path) were all explicit; it does not confirm anything the block does not list, like structure.

## How to run

```
oltc --iu 350 --um 40.5 --conn D --reg W --pm 8
oltc --mva 25 --kv 110 --conn Y --reg W --pm 8
oltc --octc --iu 800 --um 72.5 --conn D --series II --contact 6x5
oltc --iu 600 --um 72.5 --conn Y --reg W --pm 8 --structure combined
```

| Flag | Meaning |
|------|---------|
| `--iu` | Imax (lowest-tap through-current). **No** safety factor. |
| `--mva` `--kv` | Capacity path. Safety `--k` (default 1.0, same as the web app) only here. |
| `--um` | Equipment Um (kV), catalogue step. |
| `--conn Y\|D` | OLTC application: star-point vs line-end. **Not** transformer Dyn11. |
| `--reg W\|G\|0` | Reversing / coarse-fine / linear. |
| `--pm` | ± steps (W/G). Linear uses `--positions`. |
| `--octc` | Off-circuit (WSL/WSG cage/drum). |
| `--structure` | `auto` / `combined` / `compound` / `cage` / `drum` |
| `--series` | OCTC wiring II IV V VI VII VIII |
| `--ust` | Step voltage (V). Pass when the spec states volts; derived on the capacity path. |
| `--mount` | `in-tank` (default) / `on-tank` / `dry` |
| `--oil` / `--vacuum` | Switching medium. On-load defaults to vacuum; OCTC is always oil. |
| `--phases` | `I` / `II` / `III`, default III. Single-phase jobs: `--phases I`. |

`--json` still has no prices.

> npx answers "could not determine executable to run"? The working directory's own `package.json` is named `oltc-selector` and shadows the registry package. Run from another directory, or use the global install.

## Optional inputs

Defaults match the web first paint: on-load, in-tank, vacuum, structure auto, ±8 mid-3 reversing. Add these only when the spec says so:

- Step voltage `--ust`: when the spec states volts (e.g. "step voltage 2000 V"), pass `--ust 2000`, do not back-compute a percent. Give `--step-pct` or `--ust`; if both are present, `--ust` wins. Step voltage drives the across-tap insulation grade, so when unsure use `--step-pct` and let the CLI derive it.
- Mounting and medium `--mount` / `--oil`: dry-type transformers need `--mount dry`; explicit oil-arc jobs (legacy CV oil designs) take `--oil`. A nameplate saying "vacuum" needs nothing, vacuum is the default. With `--octc`, skip the medium flags; the CLI treats off-circuit as oil.

## Reading transformer data

A pasted nameplate or spec line is enough. Map it like this:

- `25 MVA 110±8×1.25%/10.5 kV` → `--mva 25 --kv 110 --pm 8 --step-pct 1.25 --reg W`. The `±N×x%` part is the tap range: N is `--pm`, x is `--step-pct`. A `±` range around a mid position is reversing (`--reg W`); a plain 0..N range is linear (`--reg 0 --positions`).
- `--kv` is the **tap-side** rated voltage, the winding the switch sits on. In `110±8×1.25%/10.5`, the taps are on 110; ignore 10.5 unless the taps are on the LV side.
- kVA → MVA: divide by 1000 (31500 kVA = 31.5 MVA).
- Rated current given instead of MVA: Imax ≈ Irated ÷ (1 − N×x%). Prefer `--mva --kv` and let the CLI do this math.
- **Dyn11 / YNd1 is the transformer vector group, not `--conn`.** `--conn Y` means the switch sits at the star point; `--conn D` means line-end delta duty. If the spec only shows the vector group and not where the taps sit, you may run with the star-point default, but the assumptions block will mark it and you must relay that and ask.
- Um: with `--mva --kv` the CLI derives it (35 → 40.5, 66 → 72.5, 110 Y → 72.5, 110 D → 126, 220 → 252). Pass `--um` only when the user states the equipment class directly.
- `--iu` is the transformer max through-current at the lowest tap. Never add a safety factor to it. `--k` exists only on the capacity path.

Missing current or voltage? Ask first, do not run. Missing tap range, star-point vs line-end, medium, or mounting? You may run; the CLI fills defaults and marks them in the assumptions block, which you relay with one short question.

> Spec line: `SFZ11-25000/110, 110±8×1.25%/10.5 kV, Dyn11, taps at HV neutral, vacuum`
> → `oltc --mva 25 --kv 110 --conn Y --reg W --pm 8 --step-pct 1.25`

## 一拖二 (OLTC + OCTC on one transformer)

A spec with both an on-load range and an off-circuit range (无载带有载, "one drags two") is **two** switches. Split it and run twice:

- On-load part (有载 ±N×x%) → normal run with that part's `--pm` / `--step-pct`.
- Off-circuit part (无载 positions / wiring) → `--octc` run with `--positions` or `--contact`, plus `--series` when the spec names the wiring.
- Both switches usually sit on the same winding: same `--iu` and `--um` for both runs unless the spec splits them.
- Spec gives only one total range and does not say how it splits between on-load and off-circuit? **Ask.** Do not invent the split.

> Spec line: `110 kV, on-load ±8×1.25% + off-circuit 5 positions (一拖二), 350 A, taps at HV neutral`
> → `oltc --iu 350 --um 72.5 --conn Y --reg W --pm 8 --step-pct 1.25`
> → `oltc --octc --iu 350 --um 72.5 --conn Y --positions 5`
> → e.g. `CV2III-350Y/72.5-10193W` (on-load) + `WSLIV-600Y/72.5-6x5A` (off-circuit). Check both against the brochure, then explain each in one or two sentences.

## Brochure check (after CLI)

See `references/brochure-check.md`. Fail the type if any of these hit:

- **CV2-500**, 2025 CV2 III is 350 and 600 only. 500 A oil compound is SV.
- **Combined III-D**, no `CM2III-…D`, `CMIII-…D`, `SHZVIII-…D`. Cover with `3x…I-` when that I type exists. **CV2 / CV / SV / HWV III-D exist.**
- **Compound grade letter**, no `CV2III-350Y/40.5B`. Combined in-tank may have B/C/D/DE.
- **Missing WSL row**, cage types must exist as a 2025-list key, not a cartesian invention.
- **Star-point Um**, Y jobs at winding ≥145 kV usually take switch **72.5**, not 145.
- **10193W operating steps**, 19 is mechanical; transformer voltage steps = **17**.

## Deep OLTC (use when explaining)

- **Iu** brochure = rated through-current of the switch. **Ium** = max of those, the number in the type (`CV2III-600`). **Imax** on the form = transformer current at lowest tap. The CLI input is Imax; the type number is Ium ≥ that duty (with ~97% headroom).
- **Combined** = diverter + tap selector (CM, CM2, SHZV, CMD). **Compound** = selector switch (CV, CV2, SV). **Cage** WSL/WDL, **drum** WSG.
- Ranking is **minimum-adequate**: CV2 → CM2 → SHZV → SHZVG. Prefer one III unit over 3× I when a legal III exists.
- Selector grade floor by Um: ≤72.5 B, 126/145 C, 170/252 D, ≥300 DE. Across-tap BIL can only raise.
- Tap code `P = 2×(±N)+mid`. Three mids share one voltage.

## After a good pick, explain like this

> `CV2III-350D/40.5-10193W`: vacuum compound covers 350 A at 40.5 kV line-end. III-D exists for CV2. ±8 mid-3 reversing is 10193W. No selector letter on compound. Lowest catalogue family that fits.
> Assumed: conn=D line-end, W reversing, ±8 steps, vacuum (default), in-tank (default), three-phase (default). I defaulted vacuum and in-tank, is that right?

With an assumptions block, follow the model and short why with the assumptions and one question. Only without a block may you stop right away. Engineering still confirms before ordering.
